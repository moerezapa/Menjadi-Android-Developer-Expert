package com.zap.movieandtvshow.model;

import com.zap.movieandtvshow.model.Movie;
import com.zap.movieandtvshow.model.TV;

import java.util.ArrayList;

public class MovieResponse {
    private ArrayList<Movie> results;
    public ArrayList<Movie> getResults() {
        return results;
    }
}
