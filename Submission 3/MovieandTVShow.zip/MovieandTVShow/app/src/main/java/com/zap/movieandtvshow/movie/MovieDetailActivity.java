package com.zap.movieandtvshow.movie;

import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.design.widget.CollapsingToolbarLayout;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.squareup.picasso.Picasso;
import com.zap.movieandtvshow.R;
import com.zap.movieandtvshow.model.Movie;

public class MovieDetailActivity extends AppCompatActivity {

    public static final String MOVIE_DETAIL = "movie_detail";
    private TextView judulfilm, popularity, tanggalrilis, overview, vote;
    private ImageView poster;

    Movie movie;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.moviedetail_movietab);

        showMovieDetail();
    }

    private void showMovieDetail() {
        movie = getIntent().getParcelableExtra(MOVIE_DETAIL);

        getSupportActionBar().setTitle(movie.getTitle());

        judulfilm = findViewById(R.id.judulfilm);
        poster = findViewById(R.id.img_poster);
        popularity = findViewById(R.id.txt_popularity);
        tanggalrilis = findViewById(R.id.txt_releasedate);
        overview = findViewById(R.id.txt_overview);
        vote = findViewById(R.id.txt_vote_average);

        judulfilm.setText(movie.getTitle());
        popularity.setText(String.valueOf(movie.getPopularity()));
        tanggalrilis.setText(movie.getReleaseDate());
        Picasso.get()
                .load(movie.getPosterPath())
                .into(poster);
        if (movie.getOverview().isEmpty())
            overview.setText("Tidak tersedia ikhtisari film untuk Bahasa Indonesia");
            else
                overview.setText(movie.getOverview());
        vote.setText(movie.getVoteAverage() + " %");
    }
}
