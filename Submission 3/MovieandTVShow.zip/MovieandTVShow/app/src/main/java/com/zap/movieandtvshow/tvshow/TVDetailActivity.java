package com.zap.movieandtvshow.tvshow;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

import com.squareup.picasso.Picasso;
import com.zap.movieandtvshow.MainActivity;
import com.zap.movieandtvshow.R;
import com.zap.movieandtvshow.model.TV;

public class TVDetailActivity extends AppCompatActivity {

    public static final String TV_DETAIL = "tv_detail";
    public static String asal;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.tvshowdetail_tbshowtab);

        showMovieDetail();
    }

    private void showMovieDetail() {
        TextView judultv, tanggalrilis, overview, vote_average, popularity;
        ImageView poster;
        TV tvShow = getIntent().getParcelableExtra(TV_DETAIL);

        getSupportActionBar().setTitle(tvShow.getName());

        judultv = findViewById(R.id.judultv);
        poster = findViewById(R.id.img_poster);
        tanggalrilis = findViewById(R.id.txt_firstairdate);
        overview = findViewById(R.id.txt_overview);
        vote_average = findViewById(R.id.txt_vote_average);
        popularity = findViewById(R.id.txt_popularity);

        judultv.setText(tvShow.getName());
        tanggalrilis.setText(tvShow.getFirst_air_date());
        Picasso.get()
                .load(tvShow.getPoster_path())
                .into(poster);
        popularity.setText(String.valueOf(tvShow.getPopularity()));
        if (tvShow.getOverview().isEmpty())
            overview.setText("Tidak tersedia ikhtisari untuk Bahasa Indonesia");
            else
                overview.setText(tvShow.getOverview());
        vote_average.setText(tvShow.getVote_average() + " %");
    }

    @Override
    public void onBackPressed() {
        Intent intent = new Intent(getApplicationContext(), MainActivity.class);
        intent.putExtra(asal, "tvdetail");
        startActivity(intent);
        finish();
    }
}
