package com.zap.moviecatalogue;

import android.os.Parcel;
import android.os.Parcelable;

public class Movie implements Parcelable {
    private int poster;
    private String name, description, tanggalrilis, sutradara;

    public Movie() {}

    public int getPoster() {
        return poster;
    }

    public void setPoster(int poster) {
        this.poster = poster;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getTanggalrilis() {
        return tanggalrilis;
    }

    public void setTanggalrilis(String tanggalrilis) {
        this.tanggalrilis = tanggalrilis;
    }

    public String getSutradara() {
        return sutradara;
    }

    public void setSutradara(String sutradara) {
        this.sutradara = sutradara;
    }

    // Parcelable
    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeInt(this.poster);
        dest.writeString(this.name);
        dest.writeString(this.description);
        dest.writeString(this.tanggalrilis);
        dest.writeString(this.sutradara);
    }

    protected Movie(Parcel in) {
        this.poster = in.readInt();
        this.name = in.readString();
        this.description = in.readString();
        this.tanggalrilis = in.readString();
        this.sutradara = in.readString();
    }

    public static final Creator<Movie> CREATOR = new Creator<Movie>() {
        @Override
        public Movie createFromParcel(Parcel source) {
            return new Movie(source);
        }

        @Override
        public Movie[] newArray(int size) {
            return new Movie[size];
        }
    };
}
