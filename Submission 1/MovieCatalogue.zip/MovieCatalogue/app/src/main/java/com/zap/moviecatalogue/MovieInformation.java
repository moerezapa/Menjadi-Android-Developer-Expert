package com.zap.moviecatalogue;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

public class MovieInformation extends AppCompatActivity {

    public static final String EXTRA_PERSON = "extra_person";
    TextView namafilm_toolbar, judulfilm, sutradarafilm, tanggalrilis, overview;
    ImageView poster;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.movieinformation_mainactivity);

        showMovieInformation();
    }

    private void showMovieInformation() {
        Movie movie = getIntent().getParcelableExtra(EXTRA_PERSON);
        namafilm_toolbar = findViewById(R.id.namafilm_toolbar);

        judulfilm = findViewById(R.id.judulfilm);
        poster = findViewById(R.id.img_poster);
        sutradarafilm = findViewById(R.id.sutradara);
        tanggalrilis = findViewById(R.id.tanggalrilis);
        overview = findViewById(R.id.txt_overview);

        namafilm_toolbar.setText(movie.getName());
        judulfilm.setText(movie.getName());
        sutradarafilm.setText(movie.getSutradara());
        tanggalrilis.setText(movie.getTanggalrilis());
        poster.setImageResource(movie.getPoster());
        overview.setText(movie.getDescription());

        findViewById(R.id.btnback).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(MovieInformation.this, MainActivity.class));
                finish();
            }
        });
    }
}
