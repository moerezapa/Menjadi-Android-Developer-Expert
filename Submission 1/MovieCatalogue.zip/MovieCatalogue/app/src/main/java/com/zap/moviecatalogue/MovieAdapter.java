package com.zap.moviecatalogue;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;

public class MovieAdapter extends BaseAdapter {

    private Context context;
    private ArrayList<Movie> movieArrayList;

    public void setMovieArrayList(ArrayList<Movie> movieArrayList) {
        this.movieArrayList = movieArrayList;
    }

    public MovieAdapter(Context context) {
        this.context = context;
        movieArrayList = new ArrayList<>();
    }

    @Override
    public int getCount() {
        return movieArrayList.size();
    }
    @Override
    public Object getItem(int i) {
        return movieArrayList.get(i);
    }
    @Override
    public long getItemId(int i) {
        return i;
    }
    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {
        /*
        pemanggilan TextView dan setText
         */
        if (view == null) {
            //Menghubungkan ViewHolder dengan View
            view = LayoutInflater.from(context).inflate(R.layout.movie_item, viewGroup, false);
        }

        ViewHolder viewHolder = new ViewHolder(view);
        Movie movie = (Movie) getItem(i);
        viewHolder.bind(movie);
        return view;
    }

    private class ViewHolder {
        private TextView txtName, txt_namaSutradara, txt_tanggal;
        private ImageView imgPhoto;
        ViewHolder(View view) {
            txtName = view.findViewById(R.id.txt_name);
            imgPhoto = view.findViewById(R.id.img_photo);
            txt_namaSutradara = view.findViewById(R.id.txt_sutradara);
            txt_tanggal = view.findViewById(R.id.txt_tanggalrilis);
        }
        void bind(Movie movie) {
            txtName.setText(movie.getName());
            imgPhoto.setImageResource(movie.getPoster());
            txt_namaSutradara.setText("Director by " + movie.getSutradara());
            txt_tanggal.setText(movie.getTanggalrilis());
        }
    }
}
