package com.zap.moviecatalogue;

import android.content.Intent;
import android.content.res.TypedArray;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    private String[] dataName;
    private String[] dataDescription;
    private String[] dataSutradara;
    private String[] dataRilis;
    private TypedArray dataPoster;
    private MovieAdapter movieAdapter;
    private ArrayList<Movie> movieArrayList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        movieAdapter = new MovieAdapter(this);
        ListView listView = findViewById(R.id.lv_movie);
        listView.setAdapter(movieAdapter);

        prepare();
        addItem();

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                Intent intent = new Intent(MainActivity.this, MovieInformation.class);
                intent.putExtra(MovieInformation.EXTRA_PERSON, movieArrayList.get(i));
                startActivity(intent);
            }
        });
    }

    private void addItem() {
        movieArrayList = new ArrayList<>();
        for (int i = 0; i < dataName.length; i++) {
            Movie movie = new Movie();
            movie.setPoster(dataPoster.getResourceId(i, -1));
            movie.setName(dataName[i]);
            movie.setDescription(dataDescription[i]);
            movie.setSutradara(dataSutradara[i]);
            movie.setTanggalrilis(dataRilis[i]);
            movieArrayList.add(movie);
        }
        movieAdapter.setMovieArrayList(movieArrayList);
    }

    // inisialisasi array
    private void prepare() {
        dataName = getResources().getStringArray(R.array.data_name);
        dataPoster = getResources().obtainTypedArray(R.array.data_photo);
        dataDescription = getResources().getStringArray(R.array.data_description);
        dataSutradara = getResources().getStringArray(R.array.data_sutradara);
        dataRilis = getResources().getStringArray(R.array.data_rilis);
    }
}
