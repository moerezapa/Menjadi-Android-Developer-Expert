package com.zap.movieandtvshow.tvshow;

import android.content.res.TypedArray;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.zap.movieandtvshow.R;
import com.zap.movieandtvshow.movie.Movie;
import com.zap.movieandtvshow.movie.MovieAdapter;

import java.util.ArrayList;
import java.util.List;

public class TVShowTab extends Fragment {

    View view;

    RecyclerView recyclerView;

    List<TVShow> tvShowList;

    private String[] tvName;
    private String[] tvOverview;
    private String[] tvCreator;
    private String[] tvRelease;
    private int[] tvScore;
    private TypedArray tvPoster;
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        view = inflater.inflate(R.layout.tvshow_tab, container, false);

        //________initialize
        recyclerView = view.findViewById(R.id.recyclerview_tvshow);
        recyclerView.setLayoutManager(new LinearLayoutManager(this.getActivity().getApplicationContext()));

        showTVList();
        return view;
    }

    // inisialisasi array
    private void prepare() {
        tvName = getResources().getStringArray(R.array.tvshow_name);
        tvPoster = getResources().obtainTypedArray(R.array.tvshow_poster);
        tvOverview = getResources().getStringArray(R.array.tvshow_overview);
        tvCreator = getResources().getStringArray(R.array.tvshow_creator);
        tvRelease = getResources().getStringArray(R.array.tvshow_release);
        tvScore = getResources().getIntArray(R.array.tvshow_score);
    }

    private void showTVList() {
        tvShowList = new ArrayList<>();
        prepare();

        // add item
        for (int i = 0; i < tvName.length; i++) {
            TVShow tvShow = new TVShow();
            tvShow.setName(tvName[i]);
            tvShow.setDescription(tvOverview[i]);
            tvShow.setSutradara(tvCreator[i]);
            tvShow.setTanggalrilis(tvRelease[i]);
            tvShow.setScore(tvScore[i]);
            tvShow.setPoster(tvPoster.getResourceId(i, -1));
            tvShowList.add(tvShow);
        }

        recyclerView.setAdapter(new TVAdapter(getContext(), tvShowList, true));
    }
}
