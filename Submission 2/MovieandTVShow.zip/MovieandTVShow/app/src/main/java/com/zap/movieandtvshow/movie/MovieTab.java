package com.zap.movieandtvshow.movie;

import android.content.res.TypedArray;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.zap.movieandtvshow.R;

import java.util.ArrayList;
import java.util.List;

public class MovieTab extends Fragment {

    View view;
    RecyclerView recyclerView;

    List<Movie> movieList;
    private String[] filmName;
    private String[] filmOverview;
    private String[] filmDirector;
    private String[] filmRelease;
    private int[] filmScore;
    private TypedArray filmPoster;
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        view = inflater.inflate(R.layout.movie_tab, container, false);

        //________initialize
        recyclerView = view.findViewById(R.id.recyclerview_film);
        recyclerView.setLayoutManager(new LinearLayoutManager(this.getActivity().getApplicationContext()));

        showFilmList();
        return view;
    }
    // inisialisasi array
    private void prepare() {
        filmName = getResources().getStringArray(R.array.film_name);
        filmPoster = getResources().obtainTypedArray(R.array.film_poster);
        filmOverview = getResources().getStringArray(R.array.film_overview);
        filmDirector = getResources().getStringArray(R.array.film_director);
        filmRelease = getResources().getStringArray(R.array.film_release);
        filmScore = getResources().getIntArray(R.array.movie_score);
    }

    private void showFilmList() {
        movieList = new ArrayList<>();
        prepare();

        // add item
        for (int i = 0; i < filmName.length; i++) {
            Movie movie = new Movie();
            movie.setName(filmName[i]);
            movie.setDescription(filmOverview[i]);
            movie.setSutradara(filmDirector[i]);
            movie.setTanggalrilis(filmRelease[i]);
            movie.setScore(filmScore[i]);
            movie.setPoster(filmPoster.getResourceId(i, -1));
            movieList.add(movie);
        }
        recyclerView.setAdapter(new MovieAdapter(getContext(), movieList, true));
    }
}
