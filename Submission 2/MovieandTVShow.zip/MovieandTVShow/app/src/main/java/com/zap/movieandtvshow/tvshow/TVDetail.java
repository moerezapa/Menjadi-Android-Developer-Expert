package com.zap.movieandtvshow.tvshow;

import android.content.Intent;
import android.provider.Settings;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.ImageView;
import android.widget.TextView;

import com.zap.movieandtvshow.MainActivity;
import com.zap.movieandtvshow.R;
import com.zap.movieandtvshow.movie.Movie;

public class TVDetail extends AppCompatActivity {

    public static String TV_DETAIL = "tv_detail";
    public static String asal;
    TextView judulfilm, sutradarafilm, tanggalrilis, overview, score;
    ImageView poster;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.tvshowdetail_tbshowtab);

        showMovieDetail();
    }

    private void showMovieDetail() {
        TVShow tvShow = getIntent().getParcelableExtra(TV_DETAIL);

        getSupportActionBar().setTitle(tvShow.getName());

        judulfilm = findViewById(R.id.judultv);
        poster = findViewById(R.id.img_poster);
        sutradarafilm = findViewById(R.id.sutradara);
        tanggalrilis = findViewById(R.id.tanggalrilis);
        overview = findViewById(R.id.txt_overview);
        score = findViewById(R.id.txt_score);

        judulfilm.setText(tvShow.getName());
        sutradarafilm.setText(tvShow.getSutradara());
        tanggalrilis.setText(tvShow.getTanggalrilis());
        poster.setImageResource(tvShow.getPoster());
        overview.setText(tvShow.getDescription());
        score.setText(tvShow.getScore() + "%");
    }

    @Override
    public void onBackPressed() {
        Intent intent = new Intent(getApplicationContext(), MainActivity.class);
        intent.putExtra(asal, "tvdetail");
        startActivity(intent);
        finish();
    }
}
