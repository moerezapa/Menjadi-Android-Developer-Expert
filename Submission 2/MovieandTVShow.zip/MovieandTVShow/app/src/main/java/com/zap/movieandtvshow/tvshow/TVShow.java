package com.zap.movieandtvshow.tvshow;

import android.os.Parcel;
import android.os.Parcelable;

public class TVShow implements Parcelable {
    private int poster;
    private String name;
    private String description;
    private String tanggalrilis;
    private String sutradara;
    private int score;

    public int getPoster() {
        return poster;
    }

    public void setPoster(int poster) {
        this.poster = poster;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getTanggalrilis() {
        return tanggalrilis;
    }

    public void setTanggalrilis(String tanggalrilis) {
        this.tanggalrilis = tanggalrilis;
    }

    public String getSutradara() {
        return sutradara;
    }

    public void setSutradara(String sutradara) {
        this.sutradara = sutradara;
    }

    public int getScore() {
        return score;
    }

    public void setScore(int score) {
        this.score = score;
    }


    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeInt(this.poster);
        dest.writeString(this.name);
        dest.writeString(this.description);
        dest.writeString(this.tanggalrilis);
        dest.writeString(this.sutradara);
        dest.writeInt(this.score);
    }

    public TVShow() {
    }

    protected TVShow(Parcel in) {
        this.poster = in.readInt();
        this.name = in.readString();
        this.description = in.readString();
        this.tanggalrilis = in.readString();
        this.sutradara = in.readString();
        this.score = in.readInt();
    }

    public static final Creator<TVShow> CREATOR = new Creator<TVShow>() {
        @Override
        public TVShow createFromParcel(Parcel source) {
            return new TVShow(source);
        }

        @Override
        public TVShow[] newArray(int size) {
            return new TVShow[size];
        }
    };
}
