package com.zap.movieandtvshow.movie;

import android.content.Intent;
import android.provider.Settings;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.zap.movieandtvshow.MainActivity;
import com.zap.movieandtvshow.R;

public class MovieDetail extends AppCompatActivity {

    public static String MOVIE_DETAIL = "movie_detail";
    TextView judulfilm, sutradarafilm, tanggalrilis, overview, score;
    ImageView poster;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.moviedetail_movietab);

        showMovieDetail();
    }

    private void showMovieDetail() {
        Movie movie = getIntent().getParcelableExtra(MOVIE_DETAIL);

        getSupportActionBar().setTitle(movie.getName());

        judulfilm = findViewById(R.id.judulfilm);
        poster = findViewById(R.id.img_poster);
        sutradarafilm = findViewById(R.id.sutradara);
        tanggalrilis = findViewById(R.id.tanggalrilis);
        overview = findViewById(R.id.txt_overview);
        score = findViewById(R.id.txt_score);

        judulfilm.setText(movie.getName());
        sutradarafilm.setText(movie.getSutradara());
        tanggalrilis.setText(movie.getTanggalrilis());
        poster.setImageResource(movie.getPoster());
        overview.setText(movie.getDescription());
        score.setText(movie.getScore() + "%");
    }
}
