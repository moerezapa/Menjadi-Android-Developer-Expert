package com.zap.movieandtvshow.localstorage;

import android.arch.lifecycle.LiveData;
import android.arch.persistence.room.Dao;
import android.arch.persistence.room.Delete;
import android.arch.persistence.room.Insert;
import android.arch.persistence.room.OnConflictStrategy;
import android.arch.persistence.room.Query;

import com.zap.movieandtvshow.model.MovieFavourite;
import com.zap.movieandtvshow.model.TVFavourite;

import java.util.List;

/*
    Note:
    @Dao
    Create a data access object in the database using an interface class
 */
@Dao
public interface MovieDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    Long insertFavourite(MovieFavourite movie);

    /*@Query("SELECT * FROM MovieFavourite")
    LiveData<List<MovieFavourite>> fetchAllMovies();*/

    @Query("SELECT * FROM MovieFavourite")
    List<MovieFavourite> getAllFavourite();

    /*@Query("SELECT * FROM MovieFavourite WHERE id =:taskId")
    LiveData<MovieFavourite> getFavouriteById(int taskId);

    @Query("SELECT * FROM MovieFavourite WHERE title = :name")
    List<MovieFavourite> findMovieFavourite(String name);*/

    //@Update
    //void updateFavourite(Movie movie);

    @Delete
    void deleteFavourite(MovieFavourite movie);
}
