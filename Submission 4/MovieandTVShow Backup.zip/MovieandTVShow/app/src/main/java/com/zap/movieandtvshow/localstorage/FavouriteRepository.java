package com.zap.movieandtvshow.localstorage;

import android.arch.lifecycle.LiveData;
import android.arch.persistence.room.Room;
import android.content.Context;
import android.os.AsyncTask;
import android.widget.Toast;

import com.zap.movieandtvshow.favourite.MovieFavAdapter;
import com.zap.movieandtvshow.model.Favourite;
import com.zap.movieandtvshow.model.Movie;

import java.util.List;

public class FavouriteRepository {
    private String DB_NAME = "db_favourite";
    private FavouriteDatabase favouriteDatabase;
    private Context context;
    public FavouriteRepository(Context context) {
        favouriteDatabase = Room.databaseBuilder(context, FavouriteDatabase.class, DB_NAME).build();
        this.context = context;
    }

    /*public void insertFavourite(String title, String description) {
        insertFavourite(title, description, false, null);
    }

    public void insertFavourite(String title,
                           String description,
                           boolean encrypt,
                           String password) {

        Favourite favourite= new Favourite();
        favourite.setTitle(title);
        favourite.setOriginal_title(title);
        //favourite.setCreatedAt(AppUtils.getCurrentDateTime());
        //favourite.setModifiedAt(AppUtils.getCurrentDateTime());
        //favourite.setEncrypt(encrypt);

        insertFavourite(favourite);
    }*/

    public void insertFavourite(final Favourite movieFav, final Context context) {
        new AsyncTask<Void, Void, Void>() {
            @Override
            protected Void doInBackground(Void... voids) {
                favouriteDatabase.daoAccess().insertFavourite(movieFav);
                return null;
            }

            @Override
            protected void onPostExecute(Void aVoid) {
                super.onPostExecute(aVoid);
                Toast.makeText(context, "Menambahkan ke dalam favorit", Toast.LENGTH_LONG).show();
            }
        }.execute();
    }

    /*public void updateFavourite(final Favourite favourite, final Context context) {
        //favourite.setModifiedAt(AppUtils.getCurrentDateTime());

        new AsyncTask<Void, Void, Void>() {
            @Override
            protected Void doInBackground(Void... voids) {
                favouriteDatabase.daoAccess().updateFavourite(favourite);
                return null;
            }

            @Override
            protected void onPostExecute(Void aVoid) {
                super.onPostExecute(aVoid);
                Toast.makeText(context, "Berhasil diubah", Toast.LENGTH_LONG).show();
            }
        }.execute();
    }*/

    public void deleteTask(final int id) {
        final LiveData<Favourite> task = getFavById(id);
        if(task != null) {
            new AsyncTask<Void, Void, Void>() {
                @Override
                protected Void doInBackground(Void... voids) {
                    favouriteDatabase.daoAccess().deleteFavourite(task.getValue());
                    return null;
                }
            }.execute();
        }
    }

    /*public void getFav(){
        //final LiveData<Favourite> task = getFavById(id);
            new AsyncTask<Void, Void, Void>() {
                @Override
                protected Void doInBackground(Void... voids) {
                    favouriteDatabase.daoAccess().fetchAllMovies();
                    return null;
                }

                @Override
                protected void onPostExecute(Void aVoid) {
                    super.onPostExecute(aVoid);

                }
            }.execute();
    }*/
    public List<Favourite> fetchAllFavourite(){
        new AsyncTask<Void, Void, List<Favourite>>() {
            @Override
            protected List<Favourite> doInBackground(Void... voids) {
                List<Favourite> favouriteList = favouriteDatabase.daoAccess().getAllFavourite();
                return favouriteList;
            }

            @Override
            protected void onPostExecute(List<Favourite> favouriteList) {
                super.onPostExecute(favouriteList);
            }
        }.execute();
        return null;
    }

    public void deleteFromFavourites(final Favourite movie) {
        new AsyncTask<Void, Void, Void>() {
            @Override
            protected Void doInBackground(Void... voids) {
                favouriteDatabase.daoAccess().deleteFavourite(movie);
                return null;
            }
        }.execute();
    }

    public LiveData<Favourite> getFavById(int id) { return favouriteDatabase.daoAccess().getFavouriteById(id); }

    public LiveData<List<Favourite>> getFavourites() { return favouriteDatabase.daoAccess().fetchAllMovies(); }
}
