package com.zap.movieandtvshow.localstorage;

import android.arch.lifecycle.LiveData;
import android.arch.persistence.room.Dao;
import android.arch.persistence.room.Delete;
import android.arch.persistence.room.Insert;
import android.arch.persistence.room.Query;
import android.arch.persistence.room.Update;

import com.zap.movieandtvshow.model.Favourite;
import com.zap.movieandtvshow.model.Movie;

import java.util.List;

/*
    Note:
    @Dao
    Create a data access object in the database using an interface class
 */
@Dao
public interface DaoAccess {

    @Insert
    Long insertFavourite(Favourite movie);

    @Query("SELECT * FROM Favourite")
    LiveData<List<Favourite>> fetchAllMovies();

    @Query("SELECT * FROM Favourite")
    List<Favourite> getAllFavourite();

    @Query("SELECT * FROM Favourite WHERE id =:taskId")
    LiveData<Favourite> getFavouriteById(int taskId);

    @Query("SELECT * FROM Favourite WHERE title = :name")
    List<Favourite> findMovieFavourite(String name);

    //@Update
    //void updateFavourite(Movie movie);

    @Delete
    void deleteFavourite(Favourite movie);
}
