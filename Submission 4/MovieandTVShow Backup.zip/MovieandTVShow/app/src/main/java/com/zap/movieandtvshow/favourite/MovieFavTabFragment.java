package com.zap.movieandtvshow.favourite;

import android.arch.persistence.room.Room;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.design.widget.Snackbar;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ProgressBar;

import com.zap.movieandtvshow.R;
import com.zap.movieandtvshow.dbsqlite.FavouriteHelper;
import com.zap.movieandtvshow.dbsqlite.LoadFavCallback;
import com.zap.movieandtvshow.localstorage.FavouriteDatabase;
import com.zap.movieandtvshow.localstorage.FavouriteRepository;
import com.zap.movieandtvshow.model.Favourite;
import com.zap.movieandtvshow.model.Movie;
import com.zap.movieandtvshow.model.MyViewModel;
import com.zap.movieandtvshow.movie.MovieAdapter;
import com.zap.movieandtvshow.movie.MovieDetailActivity;

import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.List;

import static com.zap.movieandtvshow.movie.MovieDetailActivity.REQUEST_UPDATE;

public class MovieFavTabFragment extends Fragment /*implements LoadFavCallback*/ {

    private View view;

    private static final String EXTRA_STATE = "EXTRA_STATE";
    private MovieFavAdapter movieFavAdapter;
    private FavouriteHelper favouriteHelper;

    private RecyclerView rvFav;
    private MyViewModel movieViewModel;
    ProgressBar progressBar;

    private FavouriteDatabase favouriteDatabase;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        view = inflater.inflate(R.layout.moviefavourite_fragment, container, false);

        rvFav = view.findViewById(R.id.recyclerview_filmFav);
        rvFav.setLayoutManager(new LinearLayoutManager(getActivity()));
        rvFav.setHasFixedSize(true);
        progressBar = view.findViewById(R.id.progressBar_filmFav);

        //movieFavAdapter = new MovieFavAdapter();
        //movieFavAdapter.notifyDataSetChanged();
        //rvFav.setAdapter(movieFavAdapter);

        /*if (savedInstanceState == null) {
            new LoadNotesAsync(favouriteHelper, this).execute();
        } else {
            ArrayList<Movie> list = savedInstanceState.getParcelableArrayList(EXTRA_STATE);
            if (list != null) {
                movieFavAdapter.setListNotes(list);
            }
        }*/

        // KALO BERHASIL UBAH INI
        favouriteDatabase = Room.databaseBuilder(getActivity().getApplicationContext(), FavouriteDatabase.class, "db_favourite").build();
        fetchFavourite();
        //getFavourites();
        return view;
    }

    private void getFavourites() {
        // local storage
        FavouriteRepository favouriteRepository = new FavouriteRepository(getActivity().getApplicationContext());
        List<Favourite> favouriteList = favouriteRepository.fetchAllFavourite();
        if (favouriteList != null) {
            movieFavAdapter = new MovieFavAdapter(getActivity().getApplicationContext(), favouriteList);
            rvFav.setAdapter(movieFavAdapter);
        }
    }

    /*@Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        // add to database
        if (data != null) {
            if (requestCode == MovieDetailActivity.REQUEST_ADD) {
                if (resultCode == MovieDetailActivity.RESULT_ADD) {
                    Movie movieFav = data.getParcelableExtra(MovieDetailActivity.EXTRA_MOVIE);
                    movieFavAdapter.addItem(movieFav);
                    rvFav.smoothScrollToPosition(movieFavAdapter.getItemCount() - 1);
                    showSnackbarMessage("Satu item berhasil ditambahkan");
                }
            }

            // update to database
            else if (requestCode == REQUEST_UPDATE) {
                if (resultCode == MovieDetailActivity.RESULT_UPDATE) {
                    Movie movieFavUpdate = data.getParcelableExtra(MovieDetailActivity.EXTRA_MOVIE);
                    int position = data.getIntExtra(MovieDetailActivity.EXTRA_POSITION, 0);
                    movieFavAdapter.updateItem(position, movieFavUpdate);
                    rvFav.smoothScrollToPosition(position);
                    showSnackbarMessage("Satu item berhasil diubah");
                }
                    else if (resultCode == MovieDetailActivity.RESULT_DELETE) {
                        int position = data.getIntExtra(MovieDetailActivity.EXTRA_POSITION, 0);
                        movieFavAdapter.removeItem(position);
                        showSnackbarMessage("Satu item berhasil dihapus");
                    }
            }
        }
    }

    private void showSnackbarMessage(String message) {
        Snackbar.make(rvFav, message, Snackbar.LENGTH_SHORT).show();
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        favouriteHelper.close();
    }

    @Override
    public void preExecute() {
        getActivity().runOnUiThread(new Runnable() {
            @Override
            public void run() {
                progressBar.setVisibility(View.VISIBLE);
            }
        });
    }

    @Override
    public void postExecute(ArrayList<Movie> notes) {
        progressBar.setVisibility(View.INVISIBLE);
        movieFavAdapter.setListNotes(notes);
    }

    private static class LoadNotesAsync extends AsyncTask<Void, Void, ArrayList<Movie>> {
        private final WeakReference<FavouriteHelper> weakNoteHelper;
        private final WeakReference<LoadFavCallback> weakCallback;

        private LoadNotesAsync(FavouriteHelper favouriteHelper, LoadFavCallback callback) {
            weakNoteHelper = new WeakReference<>(favouriteHelper);
            weakCallback = new WeakReference<>(callback);
        }

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            weakCallback.get().preExecute();
        }

        @Override
        protected ArrayList<Movie> doInBackground(Void... voids) {
            return weakNoteHelper.get().getAllFavourites();
        }

        @Override
        protected void onPostExecute(ArrayList<Movie> notes) {
            super.onPostExecute(notes);
            weakCallback.get().postExecute(notes);
        }
    }*/

    public void fetchFavourite(){
        new AsyncTask<Void, Void, List<Favourite>>() {
            @Override
            protected List<Favourite> doInBackground(Void... voids) {
                List<Favourite> favouriteList = favouriteDatabase.daoAccess().getAllFavourite();
                return favouriteList;
            }

            @Override
            protected void onPostExecute(List<Favourite> favouriteList) {
                super.onPostExecute(favouriteList);
                if (favouriteList != null) {
                    view.findViewById(R.id.txt_noFilmFavourite).setVisibility(View.INVISIBLE);
                    progressBar.setVisibility(View.INVISIBLE);
                    movieFavAdapter = new MovieFavAdapter(getActivity().getApplicationContext(), favouriteList);
                    rvFav.setAdapter(movieFavAdapter);
                }
            }
        }.execute();
    }
}
