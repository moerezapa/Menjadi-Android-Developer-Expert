package com.zap.movieandtvshow.movie;

import android.content.Intent;
import android.nfc.Tag;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.squareup.picasso.Picasso;
import com.zap.movieandtvshow.MainActivity;
import com.zap.movieandtvshow.R;
import com.zap.movieandtvshow.dbsqlite.FavouriteHelper;
import com.zap.movieandtvshow.localstorage.FavouriteRepository;
import com.zap.movieandtvshow.model.Favourite;
import com.zap.movieandtvshow.model.Movie;

import static android.support.constraint.Constraints.TAG;

public class MovieDetailActivity extends AppCompatActivity {

    public static final String MOVIE_DETAIL = "movie_detail";
    private TextView judulfilm, popularity, tanggalrilis, overview, vote;
    private ImageView poster;

    private final int ALERT_DIALOG_CLOSE = 10;
    private final int ALERT_DIALOG_DELETE = 20;

    public static final String EXTRA_MOVIE = "extra_movieFav";
    public static final String EXTRA_POSITION = "extra_position";
    private boolean isEdit = false;
    public static final int REQUEST_ADD = 100;
    public static final int RESULT_ADD = 101;
    public static final int REQUEST_UPDATE = 200;
    public static final int RESULT_UPDATE = 201;
    public static final int RESULT_DELETE = 301;
    private Movie movieFav;
    private int position;
    private FavouriteHelper favouriteHelper;

    Movie movie;

    // local storage
    FavouriteRepository favouriteRepository;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.moviedetail_movietab);

        showMovieDetail();
    }

    private void showMovieDetail() {
        movie = getIntent().getParcelableExtra(MOVIE_DETAIL);

        getSupportActionBar().setTitle(movie.getTitle());

        judulfilm = findViewById(R.id.judulfilm);
        poster = findViewById(R.id.img_poster);
        popularity = findViewById(R.id.txt_popularity);
        tanggalrilis = findViewById(R.id.txt_releasedate);
        overview = findViewById(R.id.txt_overview);
        vote = findViewById(R.id.txt_vote_average);

        judulfilm.setText(movie.getTitle());
        popularity.setText(String.valueOf(movie.getPopularity()));
        tanggalrilis.setText(movie.getReleaseDate());
        Picasso.get()
                .load(movie.getPosterPath())
                .into(poster);
        if (movie.getOverview().isEmpty())
            overview.setText("Tidak tersedia ikhtisari film untuk Bahasa Indonesia");
            else
                overview.setText(movie.getOverview());

        vote.setText(movie.getVoteAverage() + " %");

        // add to favourite
        favouriteHelper = FavouriteHelper.getInstance(getApplicationContext());
        favouriteHelper.open();
        movieFav = getIntent().getParcelableExtra(MOVIE_DETAIL);
        if (movieFav != null) {
            position = getIntent().getIntExtra(EXTRA_POSITION, 0);
            isEdit = true;
        }
            else
                movieFav = new Movie();
    }

    // add button to action bar
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        String fromMainActivity = getIntent().getStringExtra(MainActivity.from);
        if (fromMainActivity != null)
            getMenuInflater().inflate(R.menu.addfav_menu, menu); // add fav button
            else
                getMenuInflater().inflate(R.menu.deletefav_menu, menu); // add remove from fav button

        return super.onCreateOptionsMenu(menu);
    }

    // fungsi ketika menu diklik
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.action_addFav:
                addToMovieFavourite();
                break;
            case R.id.action_deleteFav:
                Toast.makeText(this, "Delete from favourite", Toast.LENGTH_SHORT).show();
                break;
        }
        return super.onOptionsItemSelected(item);
    }

    private void addToMovieFavourite() {
        //Toast.makeText(this, "Add to Favourite", Toast.LENGTH_SHORT).show();
        Favourite favourite = new Favourite();
        favourite.setOriginal_title(movie.getOriginalTitle());
        favourite.setTitle(movie.getTitle());
        favourite.setOverview(movie.getOverview());

        Intent intent = new Intent();
        intent.putExtra(EXTRA_MOVIE, movieFav);
        intent.putExtra(EXTRA_POSITION, position);

        /*if (isEdit) {
            long result = favouriteHelper.updateFavourite(movieFav);
            Toast.makeText(this, "Value isEdit is true", Toast.LENGTH_SHORT).show();
            /*if (result > 0) {
                setResult(RESULT_UPDATE, intent);
                finish();
            }
                else {
                    Toast.makeText(this, "Gagal mengupdate data karena resultnya " + result, Toast.LENGTH_SHORT).show();
                }
        }
            else {
                //movieFav.setDate(getCurrentDate());
                //long result = favouriteHelper.insertFavourite(movieFav);
                Toast.makeText(this, "Value isEdit is false ", Toast.LENGTH_SHORT).show();
                /*if (result > 0) {
                    movieFav.setId((int) result);
                    setResult(RESULT_ADD, intent);
                    finish();
                }
                    else
                        Toast.makeText(this, "Gagal menambah data", Toast.LENGTH_SHORT).show();
            }*/

        // yang agak fix pake yang ini, yang atas gausah
        /*if (isEdit) {
            long result = favouriteHelper.insertFavourite(movieFav);
            if (result > 0) {
                    movieFav.setId((int) result);
                    setResult(RESULT_ADD, intent);
                    Toast.makeText(this, "Menambah ke dalam favorit", Toast.LENGTH_SHORT).show();
                    finish();
                }
                    else
                        Toast.makeText(this, "Gagal menambah data karena result: "+result, Toast.LENGTH_SHORT).show();
        }*/

        // local storage
        FavouriteRepository favouriteRepository = new FavouriteRepository(getApplicationContext());
        favouriteRepository.insertFavourite(favourite,
                getApplicationContext());
    }
}
