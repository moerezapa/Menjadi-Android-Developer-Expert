package com.zap.movieandtvshow.dbsqlite;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import com.zap.movieandtvshow.model.Favourite;
import com.zap.movieandtvshow.model.Movie;

import java.util.ArrayList;

import static android.provider.BaseColumns._ID;
import static com.zap.movieandtvshow.dbsqlite.DatabaseContract.FilmFavColumns.original_title;
import static com.zap.movieandtvshow.dbsqlite.DatabaseContract.FilmFavColumns.poster_path;
import static com.zap.movieandtvshow.dbsqlite.DatabaseContract.FilmFavColumns.title;
import static com.zap.movieandtvshow.dbsqlite.DatabaseContract.TABLE_NOTE;

public class FavouriteHelper {
    private static final String DATABASE_TABLE = TABLE_NOTE;
    private static DatabaseHelper dataBaseHelper;
    private static FavouriteHelper INSTANCE;
    private static SQLiteDatabase database;

    private FavouriteHelper(Context context) {
        dataBaseHelper = new DatabaseHelper(context);
    }

    // menginisiasi database
    public static FavouriteHelper getInstance(Context context) {
        if (INSTANCE == null)
            synchronized (SQLiteOpenHelper.class) {
                if (INSTANCE == null)
                    INSTANCE = new FavouriteHelper(context);
            }
        return INSTANCE;
    }

    public void open() throws SQLException { database = dataBaseHelper.getWritableDatabase(); } // opening database

    public void close() {
        // closing database
        dataBaseHelper.close();
        if (database.isOpen())
            database.close();
    }

                                                                    // START of CRUD

    // load data dilakukan dengan getAllFavourites()
    public ArrayList<Movie> getAllFavourites() {
        ArrayList<Movie> arrayList = new ArrayList<>();
        Cursor cursor = database.query(DATABASE_TABLE, null,
                null,
                null,
                null,
                null,
                _ID + " ASC",
                null);
        cursor.moveToFirst(); // memindahkan cursor ke baris pertama
        Movie movieFav;
        if (cursor.getCount() > 0) {
            do {
                movieFav = new Movie();
                movieFav.setId(cursor.getInt(cursor.getColumnIndexOrThrow(_ID)));
                movieFav.setOriginalTitle(cursor.getString(cursor.getColumnIndexOrThrow(original_title)));
                movieFav.setTitle(cursor.getString(cursor.getColumnIndexOrThrow(title)));
                movieFav.setPosterPath(cursor.getString(cursor.getColumnIndexOrThrow(poster_path)));
                arrayList.add(movieFav);
                cursor.moveToNext(); // memindahkan cursor ke baris selanjutnya
            } while (!cursor.isAfterLast());
        }
        cursor.close(); // kalo udah dapet datanya, tutup kursor dengan close()
        return arrayList;
    }

    // saving data
    public long insertFavourite(Movie movieFav) {
        ContentValues args = new ContentValues();
        args.put(original_title, movieFav.getOriginalTitle());
        args.put(title, movieFav.getTitle());
        args.put(poster_path, movieFav.getPosterPath());

        return database.insert(
                DATABASE_TABLE,
                null,
                args);
    }

    // updating data
    public int updateFavourite(Movie movieFav) {
        ContentValues args = new ContentValues();
        args.put(original_title, movieFav.getOriginalTitle());
        args.put(title, movieFav.getTitle());
        args.put(poster_path, movieFav.getPosterPath());

        return database.update(DATABASE_TABLE, args, _ID + "= '" + movieFav.getId() + "'", null);
    }

    // deleting data
    public int deleteFavourite(int id) { return database.delete(TABLE_NOTE, _ID + " = '" + id + "'", null); }

                                                                // End of CRUD //
}
