package com.zap.movieandtvshow.localstorage;

import android.arch.persistence.room.Database;
import android.arch.persistence.room.RoomDatabase;

import com.zap.movieandtvshow.model.Favourite;
import com.zap.movieandtvshow.model.Movie;

/*
    Note:
    @Database
    Create an abstraction for the data access object
 */

@Database(entities = {Favourite.class}, version = 1, exportSchema = false)
public abstract class FavouriteDatabase extends RoomDatabase {
    public abstract DaoAccess daoAccess();
}
