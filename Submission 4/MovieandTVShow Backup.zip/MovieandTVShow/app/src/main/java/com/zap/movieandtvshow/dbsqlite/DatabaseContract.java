package com.zap.movieandtvshow.dbsqlite;

import android.provider.BaseColumns;


public class DatabaseContract {
    /*
        Untuk mempermudah akses nama tabel dan nama kolom di dalam database

        tidak ada kolom id di dalam kelas contract.
        Alasannya, kolom id sudah ada secara otomatis di dalam kelas BaseColumns
     */
    static String TABLE_NOTE = "note";

    static final class FilmFavColumns implements BaseColumns {
        //static String TITLE = "title";
        //static String DESCRIPTION = "description";
        //static String DATE = "date";
        static String original_title = "original_title";
        static String title = "title";
        static String poster_path = "poster_path";
        static String adult = "adult";
        static String overview = "overview";
        static String release_date = "release_date";
        //Integer id;
        static String originalLanguage = "originalLanguage";
        static String backdrop_path = "backdrop_path";
        static String popularity = "popularity";
        static String vote_count = "vote_count";
        static String video = "video";
        static String vote_average = "vote_average";
    }
}
