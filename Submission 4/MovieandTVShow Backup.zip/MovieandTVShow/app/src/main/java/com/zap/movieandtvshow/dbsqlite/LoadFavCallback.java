package com.zap.movieandtvshow.dbsqlite;

import com.zap.movieandtvshow.model.Favourite;
import com.zap.movieandtvshow.model.Movie;

import java.util.ArrayList;

public interface LoadFavCallback {
    void preExecute();
    void postExecute(ArrayList<Movie> notes);
}
