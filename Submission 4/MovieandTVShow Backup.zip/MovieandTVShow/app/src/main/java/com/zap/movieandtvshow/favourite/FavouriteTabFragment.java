package com.zap.movieandtvshow.favourite;

import android.os.AsyncTask;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.TextView;

import com.zap.movieandtvshow.MainActivity;
import com.zap.movieandtvshow.R;
import com.zap.movieandtvshow.localstorage.FavouriteDatabase;
import com.zap.movieandtvshow.localstorage.FavouriteRepository;
import com.zap.movieandtvshow.model.Favourite;
import com.zap.movieandtvshow.movie.MovieAdapter;

import java.util.List;

public class FavouriteTabFragment extends Fragment {
    private View view, movieView, tvView;
    private FrameLayout movieFrameLayout, tvFrameLayout;
    private TextView movieFavTabTitle, tvFavTabTitle;

    private MovieFavAdapter movieAdapter;
    private RecyclerView recyclerView;

    FavouriteDatabase favouriteDatabase;
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        view = inflater.inflate(R.layout.favourite_tab, container, false);

        // initialize view
        movieFrameLayout = view.findViewById(R.id.moviefavourite_framelayout);
        tvFrameLayout = view.findViewById(R.id.tvfavourite_framelayout);
        movieView = view.findViewById(R.id.movieView);
        tvView = view.findViewById(R.id.tvView);
        movieFavTabTitle = view.findViewById(R.id.moviefavourite_tabtitle);
        tvFavTabTitle = view.findViewById(R.id.tvfavourite_tabtitle);

        // initialize recylerview
        //recyclerView = view.findViewById(R.id.recyclerview_filmFav);
        //recyclerView.setLayoutManager(new LinearLayoutManager(this.getActivity().getApplicationContext()));

        //LOAD PAGE FOR FIRST
        loadPage(new MovieFavTabFragment());
        movieFavTabTitle.setTextColor(getResources().getColor(R.color.colorPrimary));

        tabsClickHandler();
        return view;
    }

    private void tabsClickHandler() {
        view.findViewById(R.id.moviefavourite_framelayout).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                loadPage(new MovieFavTabFragment());

                movieFavTabTitle.setTextColor(getActivity().getResources().getColor(R.color.colorPrimary));
                tvFavTabTitle.setTextColor(getActivity().getResources().getColor(R.color.colorPrimaryDark));

                movieView.setVisibility(View.VISIBLE);
                tvView.setVisibility(View.INVISIBLE);
            }
        });

        view.findViewById(R.id.tvfavourite_framelayout).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                loadPage(new TVFavTabFragment());

                movieFavTabTitle.setTextColor(getActivity().getResources().getColor(R.color.colorPrimaryDark));
                tvFavTabTitle.setTextColor(getActivity().getResources().getColor(R.color.colorPrimary));

                movieView.setVisibility(View.INVISIBLE);
                tvView.setVisibility(View.VISIBLE);
            }
        });
    }

    //LOAD PAGE FRAGMENT METHOD
    private boolean loadPage(Fragment fragment) {
        if (fragment != null) {
            getActivity().getSupportFragmentManager().beginTransaction()
                    .replace(R.id.containerfavourite, fragment)
                    .commit();
            return true;
        }
        return false;
    }

    private void getTasks() {
        // local storage
        FavouriteRepository favouriteRepository = new FavouriteRepository(getActivity().getApplicationContext());
        //favouriteRepository.getFav();

        /*class GetTasks extends AsyncTask<Void, Void, List<Favourite>> {

            @Override
            protected List<Favourite> doInBackground(Void... voids) {
                List<Favourite> taskList =
                        new FavouriteRepository(getContext()).getFav();
                        /*DatabaseClient
                        .getInstance(getApplicationContext())
                        .getAppDatabase()
                        .taskDao()
                        .getAll();
                return taskList;
            }

            @Override
            protected void onPostExecute(List<Favourite> tasks) {
                super.onPostExecute(tasks);
                movieAdapter = new MovieFavAdapter(getActivity().getApplicationContext(), tasks);
                recyclerView.setAdapter(movieAdapter);
            }
        }

        GetTasks gt = new GetTasks();
        gt.execute();*/
    }
}