package com.zap.movieandtvshow.dbsqlite;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DatabaseHelper extends SQLiteOpenHelper {
    /*
        FUNGSI CLASS INI
        menciptakan database dengan tabel yang dibutuhkan dan
        handle ketika terjadi perubahan skema pada tabel(terjadi pada metode onUpgrade())

        menggunakan variabel di DatabaseContract u/ ngisi kolom tabel
     */
    public static String DATABASE_NAME = "dbnoteapp";
    private static final int DATABASE_VERSION = 1;
    private static final String SQL_CREATE_TABLE_NOTE = String.format("CREATE TABLE %s"
                    + " (%s INTEGER PRIMARY KEY AUTOINCREMENT," +
                    " %s TEXT NOT NULL," +
                    " %s TEXT NOT NULL," +
                    " %s TEXT NOT NULL)",
            DatabaseContract.TABLE_NOTE,
            DatabaseContract.FilmFavColumns._ID,
            DatabaseContract.FilmFavColumns.original_title,
            DatabaseContract.FilmFavColumns.title,
            //DatabaseContract.FilmFavColumns.overview,
            //DatabaseContract.FilmFavColumns.backdrop_path,
            DatabaseContract.FilmFavColumns.poster_path
            //DatabaseContract.FilmFavColumns.adult,
            //DatabaseContract.FilmFavColumns.originalLanguage,
            //DatabaseContract.FilmFavColumns.popularity,
            //DatabaseContract.FilmFavColumns.release_date,
            //DatabaseContract.FilmFavColumns.video,
            //DatabaseContract.FilmFavColumns.vote_average,
            //DatabaseContract.FilmFavColumns.vote_count
    );

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    // required method to operate SQLiteOpenHelper
    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(SQL_CREATE_TABLE_NOTE);
    }
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + DatabaseContract.TABLE_NOTE);
        onCreate(db);
    }
}
