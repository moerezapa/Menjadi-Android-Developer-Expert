package com.zap.movieandtvshow.favourite;

import android.content.Context;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.widget.CardView;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.squareup.picasso.Picasso;
import com.zap.movieandtvshow.R;
import com.zap.movieandtvshow.model.Favourite;
import com.zap.movieandtvshow.model.Movie;
import com.zap.movieandtvshow.movie.MovieDetailActivity;

import java.util.ArrayList;
import java.util.List;

public class MovieFavAdapter extends RecyclerView.Adapter<MovieFavAdapter.ViewHolder> {

    private Context context;
    private List<Favourite> movieItems = new ArrayList<>();
    //private ArrayList<Favourite> listFav = new ArrayList<>();

    /*public void setListNotes(ArrayList<Movie> listNotes) {
        if (listNotes.size() > 0) {
            this.listFav.clear();
        }
        this.listFav.addAll(listNotes);
        notifyDataSetChanged();
    }*/

    /**
     * Gunakan method ini jika semua datanya akan diganti
     *
     * @param items kumpulan data baru yang akan mengganti semua data yang sudah ada
     */
    /*public void setData(Context context, ArrayList<Movie> items) {
        movieItems.clear();
        movieItems.addAll(items);
        this.context = context;
        notifyDataSetChanged();
    }
    public ArrayList<Movie> getListFavourite() {
        return listFav;
    }

    // create, update, and delete item in recyclerview
    public void addItem(Movie favourite) {
        this.listFav.add(favourite);
        notifyItemInserted(listFav.size() - 1);
    }
    public void updateItem(int position, Movie favourite) {
        this.listFav.set(position, favourite);
        notifyItemChanged(position, favourite);
    }
    public void removeItem(int position) {
        this.listFav.remove(position);
        notifyItemRemoved(position);
        notifyItemRangeChanged(position,listFav.size());
    }*/

    public MovieFavAdapter(Context context, List<Favourite> favouriteList) {
        this.context = context;
        this.movieItems = favouriteList;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View mView = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.movie_item, viewGroup, false);
        return new ViewHolder(mView);
    }

    @Override
    public void onBindViewHolder(@NonNull final ViewHolder viewHolder, final int i) {
        viewHolder.txt_filmname.setText(movieItems.get(viewHolder.getAdapterPosition()).getOriginal_title());
        viewHolder.txt_releasedate.setText(movieItems.get(viewHolder.getAdapterPosition()).getRelease_date());
        viewHolder.txt_popularity.setText(context.getResources().getString(R.string.popularity) + ": " + movieItems.get(i).getOverview());
        /*Picasso.get()
                .load(movieItems.get(viewHolder.getAdapterPosition()).getPosterPath())
                .into(viewHolder.poster);*/

        viewHolder.cardView_film.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                /*Intent intent = new Intent(context, MovieDetailActivity.class);
                intent.putExtra(MovieDetailActivity.MOVIE_DETAIL, movieItems.get(viewHolder.getAdapterPosition()));
                context.startActivity(intent);*/
                Toast.makeText(context, "Testing", Toast.LENGTH_SHORT).show();
            }
        });
    }

    @Override
    public int getItemCount() { return movieItems.size(); }

    @Override
    public long getItemId(int position) {
        return super.getItemId(position);
    }

    public class ViewHolder extends RecyclerView.ViewHolder {

        TextView txt_filmname, txt_releasedate, txt_popularity;
        ImageView poster;

        CardView cardView_film;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);

            txt_filmname = itemView.findViewById(R.id.txt_name);
            txt_releasedate = itemView.findViewById(R.id.txt_tanggalrilis);
            txt_popularity = itemView.findViewById(R.id.txt_popularity);

            poster = itemView.findViewById(R.id.movie_poster);

            cardView_film = itemView.findViewById(R.id.cardview_film);
        }
    }
}
