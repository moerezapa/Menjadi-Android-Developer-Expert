package zap.dev.movieandtvcatalogue.model;

import java.util.ArrayList;

public class MovieResponse {
    private ArrayList<Movie> results;
    public ArrayList<Movie> getResults() {
        return results;
    }
}
