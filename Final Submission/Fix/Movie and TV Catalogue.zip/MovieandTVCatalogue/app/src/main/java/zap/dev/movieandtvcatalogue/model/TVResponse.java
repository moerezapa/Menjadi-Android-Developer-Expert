package zap.dev.movieandtvcatalogue.model;

import java.util.ArrayList;

public class TVResponse {
    private ArrayList<TV> results;
    public ArrayList<TV> getResults() {
        return results;
    }
}
