package com.zap.movieandtvshow.localdb;

import android.arch.persistence.room.Database;
import android.arch.persistence.room.RoomDatabase;

import com.zap.movieandtvshow.model.MovieFavourite;
import com.zap.movieandtvshow.model.TVFavourite;

/*
    Note:
    @Database
    Create an abstraction for the data access object
 */

// update version if there's change
@Database(entities = {MovieFavourite.class, TVFavourite.class}, version = 2, exportSchema = false)
public abstract class AppDatabase extends RoomDatabase {
    public abstract MovieDao daoAccess();
    public abstract TVDao tvDao();
}
