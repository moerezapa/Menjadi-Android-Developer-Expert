package com.zap.movieandtvshow.widget;

import android.appwidget.AppWidgetManager;
import android.arch.persistence.room.Room;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.widget.RemoteViews;
import android.widget.RemoteViewsService;

import com.squareup.picasso.Picasso;
import com.zap.movieandtvshow.R;
import com.zap.movieandtvshow.localdb.AppDatabase;
import com.zap.movieandtvshow.localdb.DBRepository;
import com.zap.movieandtvshow.model.MovieFavourite;

import java.util.List;

public class StackWidgetService extends RemoteViewsService {

    @Override
    public RemoteViewsFactory onGetViewFactory(Intent intent) {
        return new WidgetRemoteViewsFactory(this.getApplicationContext());
    }
}

class WidgetRemoteViewsFactory implements RemoteViewsService.RemoteViewsFactory {

    private final Context mContext;

    private List<MovieFavourite> movieFavouriteArrayList;
    private int mAppWidgetId;
    private AppDatabase appDatabase;

    WidgetRemoteViewsFactory(Context context) {
        mContext = context;
    }

    @Override
    public void onCreate() {

    }

    @Override
    public void onDataSetChanged() {
        appDatabase = Room.databaseBuilder(mContext, AppDatabase.class, DBRepository.DB_NAME).build();
        new AsyncTask<Void, Void, List<MovieFavourite>>() {
            @Override
            protected List<MovieFavourite> doInBackground(Void... voids) {
                List<MovieFavourite> movieFavouriteList = appDatabase.daoAccess().getAllFavourite();
                return movieFavouriteList;
            }

            @Override
            protected void onPostExecute(List<MovieFavourite> movieFavouriteList) {
                super.onPostExecute(movieFavouriteList);
                if (movieFavouriteList != null)
                    movieFavouriteArrayList = movieFavouriteList;
            }
        }.execute();
    }

    @Override
    public void onDestroy() {

    }

    @Override
    public int getCount() {
        return movieFavouriteArrayList.size();
    }

    @Override
    public RemoteViews getViewAt(int position) {
        final RemoteViews rv = new RemoteViews(mContext.getPackageName(), R.layout.widget_item);

        try {
            Bitmap b = Picasso.get().load(movieFavouriteArrayList.get(position).getPoster_path()).get();
            rv.setImageViewBitmap(R.id.img_moviewidget, b);
        }
        catch (Exception e) {
            Log.d("Test", e.getMessage().toString());
        }

        //rv.setImageViewBitmap(R.id.img_moviewidget, mWidgetItems.get(position));
        //rv.setTextViewText(R.id.txt, item.getTitle());
        Bundle extras = new Bundle();
        extras.putInt(MovieFavWidget.EXTRA_ITEM, position);
        Intent fillInIntent = new Intent();
        fillInIntent.putExtras(extras);
        rv.setOnClickFillInIntent(R.id.img_moviewidget, fillInIntent);

        return rv;
    }

    @Override
    public RemoteViews getLoadingView() {
        return null;
    }

    @Override
    public int getViewTypeCount() {
        return 1;
    }

    @Override
    public long getItemId(int i) {
        return 0;
    }

    @Override
    public boolean hasStableIds() {
        return false;
    }
}
