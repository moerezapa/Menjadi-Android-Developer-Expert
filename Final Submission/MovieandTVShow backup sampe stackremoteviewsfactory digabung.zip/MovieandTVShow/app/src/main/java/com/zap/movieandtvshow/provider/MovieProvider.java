package com.zap.movieandtvshow.provider;

import android.content.ContentProvider;
import android.content.ContentValues;
import android.content.UriMatcher;
import android.database.Cursor;
import android.net.Uri;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;

public class MovieProvider extends ContentProvider {

    /*
        deklarasikan variabel terlebih dahulu dan definisikan UriMatcher
        untuk mengecek URI yang masuk, apakah bersifat all atau ada tambahan id-nya.
     */
    /** The authority of this content provider. */
    public static final String AUTHORITY = "com.delaroystudios.roomcontentprovider.provider";

    /** The URI for the Menu table. */
    public static final Uri URI_MENU = Uri.parse(
            "content://" + AUTHORITY + "/" + "favourite_db");

    /** The match code for some items in the Menu table. */
    private static final int CODE_MENU_DIR = 1;

    /** The match code for an item in the Menu table. */
    private static final int CODE_MENU_ITEM = 2;

    /** The URI matcher. */
    private static final UriMatcher MATCHER = new UriMatcher(UriMatcher.NO_MATCH);

    static {
        MATCHER.addURI(AUTHORITY, "favourite_db", CODE_MENU_DIR);
        MATCHER.addURI(AUTHORITY, "favourite_db" + "/*", CODE_MENU_ITEM);
    }

    public MovieProvider() {
    }

    @Override
    public boolean onCreate() {
        return false;
    }
    @Nullable
    @Override
    public Cursor query(@NonNull Uri uri, @Nullable String[] strings, @Nullable String s, @Nullable String[] strings1, @Nullable String s1) {
        /*final int code = MATCHER.match(uri);
        if (code == CODE_MENU_DIR || code == CODE_MENU_ITEM) {
            final Context context = getContext();
            if (context == null)
                return null;

            //MovieDao movieDao = SampleDatabase.getInstance(context).menu();
            Cursor cursor;
            if (code == CODE_MENU_DIR)
                cursor = movieDao.selectAll();
                else
                    cursor = movieDao.selectById(ContentUris.parseId(uri));

            cursor.setNotificationUri(context.getContentResolver(), uri);
            return cursor;
        }
            else
                throw new IllegalArgumentException("Unknown URI: " + uri);*/

            return null;
    }

    @Nullable
    @Override
    public String getType(@NonNull Uri uri) {
        return null;
    }

    @Nullable
    @Override
    public Uri insert(@NonNull Uri uri, @Nullable ContentValues contentValues) {
        return null;
    }

    @Override
    public int update(@NonNull Uri uri, @Nullable ContentValues contentValues, @Nullable String s, @Nullable String[] strings) {
        return 0;
    }

    @Override
    public int delete(@NonNull Uri uri, @Nullable String s, @Nullable String[] strings) {
        return 0;
    }
}
