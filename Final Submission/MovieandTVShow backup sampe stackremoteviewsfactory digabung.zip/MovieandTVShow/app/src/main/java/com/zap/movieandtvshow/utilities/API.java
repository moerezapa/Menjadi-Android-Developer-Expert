package com.zap.movieandtvshow.utilities;

import com.zap.movieandtvshow.model.MovieResponse;
import com.zap.movieandtvshow.model.TVResponse;

import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Query;

public interface API {
    @GET("discover/movie")
    Call<MovieResponse> getMovies(
            @Query("api_key") String apiKey,
            @Query("language") String language);

    @GET("discover/tv")
    Call<TVResponse> getTV(
            @Query("api_key") String apiKey,
            @Query("language") String language);

    @GET("search/movie")
    Call<MovieResponse> searchMovie(
                            @Query("api_key") String apiKey,
                            @Query("query") String moviename);
    @GET("search/tv")
    Call<TVResponse> searchTV(
            @Query("api_key") String apiKey,
            @Query("query") String tvname);

    @GET("movie/now_playing")
    Call<MovieResponse> getNowPlaying(@Query("api_key") String apiKey);

    @GET("movie/upcoming")
    Call<MovieResponse> getUpcoming(@Query("api_key") String apiKey);

}
