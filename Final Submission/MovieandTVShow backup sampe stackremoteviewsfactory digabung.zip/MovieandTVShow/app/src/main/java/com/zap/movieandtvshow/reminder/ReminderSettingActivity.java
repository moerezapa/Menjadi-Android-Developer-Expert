package com.zap.movieandtvshow.reminder;

import android.content.Intent;
import android.provider.Settings;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Switch;

import com.zap.movieandtvshow.R;

public class ReminderSettingActivity extends AppCompatActivity {

    private DailyReminderReceiver dailyReminderReceiver;
    private UpcomingReceiver upcomingReceiver;

    private Boolean isReleaseReminder, isDailyReminder;
    private Switch switchDailyReminder, switchReleaseReminder;

    public static final String TYPE_REMINDER_PREF = "reminderAlarm";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_reminder_setting);

        initView();
    }

    private void initView() {
        getSupportActionBar().setTitle(getString(R.string.setting_reminder));

        switchDailyReminder = findViewById(R.id.switch_dailyreminder);
        switchReleaseReminder = findViewById(R.id.switch_releasereminder);

        dailyReminderReceiver = new DailyReminderReceiver();
        upcomingReceiver = new UpcomingReceiver();

        switchDailyReminder.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                isDailyReminder = switchDailyReminder.isChecked();
                if (isDailyReminder)
                    dailyReminderReceiver.setRepeatingAlarm(ReminderSettingActivity.this, DailyReminderReceiver.TYPE_REPEATING
                            ,"07:00", getString(R.string.daily_reminder));
                    else
                        dailyReminderReceiver.cancelAlarm(getApplicationContext(), DailyReminderReceiver.TYPE_REPEATING);
            }
        });

        switchReleaseReminder.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                isReleaseReminder = switchReleaseReminder.isChecked();
                if (isReleaseReminder){
                    switchReleaseReminder.setEnabled(true);
                    //appPreference.setUpcoming(isReleaseReminder);
                    releaseReminderOn();
                }
                    else {
                        switchReleaseReminder.setChecked(false);
                        //appPreference.setUpcoming(isReleaseReminder);
                        releaseReminderOff();
                    }
                //Toast.makeText(ReminderSettingActivity.this, "Value  isReleaseReminder is " + isReleaseReminder, Toast.LENGTH_SHORT).show();
            }
        });

        findViewById(R.id.change_language).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(Settings.ACTION_LOCALE_SETTINGS));
            }
        });
    }
    private void releaseReminderOn() {
        //notificationPreference.setReminderReleaseTime(time);
        //notificationPreference.setReminderReleaseMessage(message);
        upcomingReceiver.setAlarm(this, TYPE_REMINDER_PREF, "08:00", getResources().getString(R.string.upcoming_reminder_msg));
    }

    private void releaseReminderOff() { upcomingReceiver.cancelAlarm(this); }

}
